ZRPacker v1.0

fetures:
► full packing and unpacking of Zenith™ resorce packs (.zrp)
► user selected key (at least 16 bytes, if its over 16 itl cut the key to fit)
► unpacking of zrp's in a copple clicks
► included a demo key (you can edit it with ether hxd or notepad to whatever you want)

not affiliated with arduano/Zenith-MIDI in any way hell, the creator was
kinda mad apon the cration of this tool lmao

also, (not boring you with some 1.6MB legal wank ;) )
this software comes with no warentee, blablabla